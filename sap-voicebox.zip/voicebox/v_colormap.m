function [rgb,y,l]=v_colormap(map,m,n,p)
%V_COLORMAP set and plot color map
%
%   Usage: (1) v_colormap([],'g');          % plot the current color map
%
%          (2) v_colormap([],'',256);       % intepolate the current color map to 256 entries
%
%          (3) v_colormap('copper','y');    % make copper color map linear in luminance
%
%          (4) v_colormap('copper','L');    % make copper color map linear in lightness^2
%
%          (5) imagesc(x,max(abs(x(:)))*[-1 31/32]);        % plot an image containing signed data and set the color range
%              v_colormap('v_bipveey');                     % select a bipolar colormap
%              colorbar;                                    % show the color bar
%
%          (6) rev=360;                                                     % 360 for degrees or 2*pi for radians
%              nmap=64;                                                     % number of map entries
%              phase=repmat(linspace(0,2*rev,200),200,1);                   % create 2 cycles of linear phase
%              imagesc(mod(phase+rev*0.5/nmap,rev)-rev*0.5/nmap,rev*[-0.5 nmap-0.5]/nmap);    % ensure data range is rev*[-1 127]/128
%              v_colormap('v_circrby','y',nmap);                                     % select a circular colormap
%              colorbar;
%
%  Inputs:
%           map  Either an (r,3) array specifying the RGB colourmap entries
%                or else a string specifying a bult-in colour map. Use []
%                to leave the colour map unchanged.
%                Standard maps are:
%                   'Jet','HSV','Hot','Cool','Spring','Summer','Autumn',
%                   'Winter','Gray','Bone','Copper','Pink','Lines','Parula'
%                Additional maps, all with 64 entries, are:
%                   'v_thermliny'  thermal scale that is linear in luminance
%                                  Varies from black through blue, red, yellow to white.
%                                  Luminance varies linearly from black to white.
%                   'v_bipliny'    bipolar scale that is linear in luminance
%                                  Negative values are blue/turquoise and postive value are orange/yellow.
%                                  Luminance varies linearly from black to white with zero at 50.8% gray.
%                   'v_bipveey'    bipolar scale that is V-shaped in luminance
%                                  Negative values are blue/turqoise and positive values are red/yellow.
%                                  Luminance is proportional to absolute value with zero=black.
%                   'v_circrby'    Circular scale that is V-shaped in luminance and is red for
%                                  entries 2-32 and blue for entries 34-64. Intended for plotting phase.
%                For 'v_bipliny' and 'v_circrby', zero corresponds to entry 33 and so the range of values
%                is -32:31 or, equivalently, either [-1, +0.96875=31/32] or [-1.0323=-32/31,+1]. See usage
%                example (5) above.
%
%             m  Mode string:
%                   'g' to plot information about the color map
%                   'y' to force luminance^p to be linear or V-shaped (two linear segments)
%                   'l' to force lightness^p to be linear or V-shaped (two linear segments)
%                   'Y' like 'y' but with default p=0.667
%                   'L' like 'l' but with default p=2
%                   'f' flips the map to reverse its order
%                   'b' force minimum luminance >=0.05 (or 0.1 for 'B')
%                   'w' force maximum luminance <=0.95 (or 0.9 for 'W')
%                   'k' to keep the current color map (i.e. don't update it to a new one]
%
%             n  the number of entries in the colourmap or the number in
%                each linearly-interpolated segment excluding the entry shared
%                with the previous segment. The total number of entries is n=sum(n).
%                For modes 'y','Y','l','L' the number of segments must be 1
%                or 2; otherwise the number of segments must be 1 or r-1.
%
%             p  power law to use for linearized luminance or lightness [default p=1]
%                see the description of 'y' and 'l' for its effect
%
% Outputs:       Note that the colormap will be updated regardless of whether outputs are
%                specified. Use the 'k' option to supress updating.
%
%           rgb  RGB color map entries; one per row.
%                All values will be in the range 0 to 1
%
%             y  column vector of luminance values (from CIEXYZ colour space)
%
%             l  column vector of lightness values (lightness is the perceived brightness from CIELUV colour space)

% Bugs/Suggestions:
%  (1) Should allow an optional "target" input (like colormap(0) does).

%      Copyright (C) Mike Brookes 2012-2018
%      Version: $Id: v_colormap.m 10866 2018-09-21 17:32:44Z dmb $
%
%   VOICEBOX is a MATLAB toolbox for speech processing.
%   Home page: http://www.ee.ic.ac.uk/hp/staff/dmb/voicebox/voicebox.html
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This program is free software; you can redistribute it and/or modify
%   it under the terms of the GNU Lesser General Public License as published by
%   the Free Software Foundation; either version 3 of the License, or
%   (at your option) any later version.
%
%   This program is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU Lesser General Public License for more details.
%
%   You can obtain a copy of the GNU Lesser General Public License from
%   https://www.gnu.org/licenses/ .
%    See files gpl-3.0.txt and lgpl-3.0.txt included in this distribution.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
persistent maps nams mcal modes nmap nszs pows la lb lc lci laci lk lq yv
if isempty(maps)
    lk=(6/29)^3;
    la=841/108;
    lb=4/29;
    lc=1.16;
    lq=la*lc*lk;
    lci=1/lc;
    laci=lci/la;
    %     yv=inv([1.0 0.956 0.621; 1.0 -0.272 -0.647; 1.0 -1.106 1.703]);
    %     yv=yv(:,1);
    yv=[0.2126; 0.7152; 0.0722];                    % Mapping from RGB to luminance
    % specifications for local color maps
    nams={'v_thermliny','v_bipliny','v_bipveey','v_circrby'};
    mcal=[1 1 1 1];                                 % +1 if need to calculate maps entry
    modes={'y' 'y' 'y' 'y'};                        % modes for map calculation
    nszs={64 64 [33 31]  [33 32]};                  % linear interpolation regions
    nmap=[64 64 64 64];                             % final map size
    pows=[1 1 1 1];                                 % powers for maps
    % 'v_thermliny'
    maps{1}=[0 0 0; 72 0 167; 252 83 16; 255 249 0; 255 255 255]/255;
    % 'v_bipliny': bipolar map with grayscale linearity
    maps{2}=[0 0 0; 0 2 203; 1 101 226; 128 128 128; 252 153 12; 252 245 0; 252 249 18; 252 252 252]/252;
    % 'v_bipveey'
    maps{3}=[0 0.95 1; 0 0 0.9; 0 0 0; 0.5 0 0; 0.80 0.78 0];
    % 'v_circrby'
    maps{4}=[0 0 0; 1 0.183 0; 1 0.9 0; 1 1 1; 0 1 0.8; 0 0.379 1; 0 0 0];
end
if nargin<2
    m='';
end
if nargin<4
    if any(m=='Y')
        p=2/3;
    elseif any(m=='L')
        p=2;
    else
        p=1;                            % power to raise lightness/luminance to
    end
end
pr=1/p;
um=m;
m=lower(m);                                     % convert mode letters to lower case
oldmap=colormap;                                % get existing map
rest=0;                                         % do not restore old map by default
if nargin==0 || numel(map)==0                   % use existing map
    rgb=oldmap;
elseif ischar(map)                              % if map given as a string
    ix=find(strcmpi(map,nams),1);               % check if it is one of ours
    if numel(ix)                                % if it is one of ours
        if mcal(ix)                             % need to calculate the map the first time around
            maps{ix}=v_colormap(maps{ix},modes{ix},nszs{ix},pows(ix));
            mcal(ix)=0;                         % don't calculate it again
            maps{ix}=maps{ix}(1:nmap(ix),:);    % only keep the first nmap(ix) entries
        end
        rgb=maps{ix};
    else
        rgb=colormap(map);              % not one of ours - just pass it on to standard colormap function
        rest=any(m=='k');               % need to restore the old map if 'k' option is set
    end
else
    rgb=map; % numeric map specified
end
if any(m=='y') ||  any(m=='l') || (nargin>2 && numel(n)>0) % need to do linear interpolation
    nm=size(rgb,1);
    if any(m=='y') ||  any(m=='l')
        y=rgb*yv;  % convert map to luminance
        up=y(2:nm)>y(1:nm-1); % find increasing
        ex=up(1:nm-2)~=up(2:nm-1); % +1 for a peak or valley
        yd=2*up(1)-1; % +1 if y initially increasing
        switch sum(ex)
            case 0 % monotonic
                if nargin<3
                    r=nm;
                else
                    r=n(1);
                end
                if any(m=='y')
                    l=y([1 nm]).^p;
                    tt=(l(1)+(0:r-1)'*(l(2)-l(1))/(r-1)).^pr; % target luminances
                else
                    tt=y([1 nm]');
                    l=(lc*(la*tt+(tt>lk).*(tt.^(1/3)-la*tt-lb))).^p;
                    tt=(l(1)+(0:r-1)'*(l(2)-l(1))/(r-1)).^pr; % target lightnesses
                    tt=laci*tt+(tt>lq).*((lci*tt+lb).^3-laci*tt); % target luminances
                end
                [ss,ix]=sort([tt;y]*yd);
            case 1 % V-shaped
                ipk=find(ex,1)+1;  % position of peak/valley in y
                if nargin<3
                    n=[ipk nm-ipk];  % size of linear segments
                end
                r=n(1)+n(2);  % total size of map
                if any(m=='y')
                    l=y([1 ipk nm]).^p;
                    tt=(l(2)+[(1-n(1):0)*(l(2)-l(1))/(n(1)-1) (1:n(2))*(l(3)-l(2))/(n(2))]').^pr; % target luminances
                else
                    tt=y([1 ipk nm]');
                    l=(lc*(la*tt+(tt>lk).*(tt.^(1/3)-la*tt-lb))).^p;
                    tt=(l(2)+[(1-n(1):0)*(l(2)-l(1))/(n(1)-1) (1:n(2))*(l(3)-l(2))/(n(2))]').^pr; % target lightnesses
                    tt=laci*tt+(tt>lq).*((lci*tt+lb).^3-laci*tt); % target luminances
                end
                [ss,ix]=sort([tt(1:n(1))-y(ipk); y(ipk)-tt(n(1)+1:r);y(1:ipk)-y(ipk); y(ipk)-y(ipk+1:nm)]*yd);
            otherwise
                error('luminance has more than two monotonic segments');
        end
    else                % just linearly interpolate the given values
        if numel(n)==nm-1
            r=sum(n);
            y=[1;cumsum(n(:))];
        else
            r=n(1);
            y=1+(0:nm-1)'*(r-1)/(nm-1);
        end
        tt=(1:r)';
        [ss,ix]=sort([tt;y]);
    end
    jx=zeros(size(ix));
    jx(ix)=1:numel(jx);
    jx=min(max(jx(1:r)-(1:r)',1),nm-1);
    al=(tt-y(jx))./(y(jx+1)-y(jx)); % fraction of upper sample to include
    rgb=rgb(jx,:)+(rgb(jx+1,:)-rgb(jx,:)).*al(:,ones(1,3)); % update the map
end
if any(m=='f')
    rgb=rgb(end:-1:1,:);
end
y=rgb*yv;  % convert RGB to luminance
if any(m=='b') || any(m=='w') % need to constrain luminance
    minyt=0.05*(any(m=='b')+any(um=='B')); % target minimum luminance
    maxyt=1-0.05*(any(m=='w')+any(um=='W')); % target maximum luminance
    maxy=max(y);
    miny=min(y);
    if maxy>maxyt || miny<minyt
        maxy=max(maxy,maxyt);
        miny=min(miny,minyt);
        rgb=(rgb-miny)*(maxyt-minyt)/(maxy-miny)+minyt;
        y=rgb*yv;  % convert RGB to luminance
    end
end
l=lc*(la*y+(y>lk).*(y.^(1/3)-la*y-lb)); % convert luminance to lightness
if rest
    colormap(oldmap);  % restore the old map
elseif ~isequal(rgb,oldmap)
    colormap(rgb); % update the system map
end
if any(m=='g')
    sp=[1 2 2];
    ssp=sum(sp);
    axw=0.05;
    nc=size(rgb,1);  % size of color map
    hsv=rgb2hsv(rgb);
    subplot(ssp,1,sp(1)+(1:sp(2)));
    plot(1:nc,y,'--k');
    hold on
    plot(1:nc,rgb(:,1),'-r');
    plot(1:nc,rgb(:,2),'-g');
    plot(1:nc,rgb(:,3),'-b');
    hold off
    axis([0.5 nc+0.5 -axw 1+axw]);
    legend('Y','R','G','B','location','best');
    ylabel('RGB + Y');
    subplot(ssp,1,sp(1)+sp(2)+1:ssp);
    plot(1:nc,l,'--k');
    hold on
    plot(1:nc,hsv(:,1),'-r');
    plot(1:nc,hsv(:,2),'-g');
    plot(1:nc,hsv(:,3),'-b');
    hold off
    axis([0.5 nc+0.5 -axw 1+axw]);
    legend('L*','H','S','V','location','best');
    ylabel('HSV + L*');
    subplot(ssp,1,1:sp(1));
    image(permute(reshape([rgb y(:,[1 1 1])],[nc,3,2]),[3 1 2]));
    set(gca,'YTick',[]);
end
